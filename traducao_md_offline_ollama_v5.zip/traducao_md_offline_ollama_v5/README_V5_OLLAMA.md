
# Tradução Técnica de Markdown (EN → PT‑BR) — **V5 (Ollama, 100% local)**

Este pacote traduz **`arquivoorigem.md`** para **português (Brasil)** usando **Ollama** (LLM local, offline),
sem enviar o arquivo ou trechos para a nuvem. Todo o processamento ocorre **na sua máquina**.

## 🔧 Requisitos
- **Ollama** instalado (Windows/macOS/Linux)
- Python 3.8+

## ⚙️ Instalação do Ollama (resumo)
1. Baixe e instale o **Ollama** (veja o site oficial). Em Linux, há script `curl -fsSL https://... | sh`.
2. Abra um terminal e rode **um modelo** para baixá-lo e iniciar o serviço local:
   ```bash
   ollama run phi3:instruct
   ```
   > Dica: você pode usar `llama3.1:8b-instruct`, `mistral:7b-instruct`, `qwen2:7b-instruct`, etc.
3. Verifique o serviço local (opcional):
   ```bash
   curl http://127.0.0.1:11434/api/tags
   ```

## 🚀 Como usar este pacote
1. (Opcional) Crie e ative um ambiente virtual:
   ```bash
   python -m venv .venv
   # Windows
   .venv\Scripts\activate
   # Linux/macOS
   source .venv/bin/activate
   ```
2. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```
3. Coloque **`arquivoorigem.md`** ao lado do script.
4. (Opcional) Ajuste o **glossário** `glossario_termos_nao_traduzir.txt` com termos internos (um por linha).
5. (Opcional) Crie um `.env` com configurações:
   ```ini
   OLLAMA_HOST=http://127.0.0.1:11434
   LLM_MODEL=phi3:instruct
   TEMPERATURE=0.2
   MAX_CHARS_PER_ITEM=4000
   ```
6. Execute:
   ```bash
   python traduz_md_ollama_v5.py
   ```
7. Saída: `arquivoorigem.pt-BR.md`.

## 🧠 Preservação técnica (Modo Técnico)
- **Blocos de código** e **inline code** — intocados.  
- **Links** — traduz apenas o rótulo; a **URL** fica intacta.  
- **Imagens** — preservadas (ALT preservado por padrão).  
- **URLs** soltas, **front‑matter YAML** — preservados.  
- **Chaves JSON/YAML** (`"DEBUG":`, `ALLOWED_HOSTS:`) — congeladas.  
- **Identificadores**: `snake_case`, `Camel/PascalCase`; **módulos dotted**; **caminhos**; **comandos** — congelados.  
- **Glossário** (arquivo + padrão) para termos que **não devem** ser traduzidos.

## 📈 Dicas de performance
- Prefira modelos menores (ex.: `phi3:instruct`, `llama3.1:8b-instruct`) se não tiver GPU.
- Se tiver **GPU**, modelos maiores tendem a traduzir melhor com boa velocidade.
- Ajuste `MAX_CHARS_PER_ITEM` para chunks menores caso o modelo erre JSON quando o texto for longo.

## 🧪 Teste rápido
Traduza `exemplos_teste.md` e confira que:
- `QuerySet`, `APIView`, `ModelAdmin`, `django.contrib.auth`, `python manage.py migrate`, `"DEBUG":`, `/var/www/app/settings.py` **permanecem intactos**;  
- O **texto corrido** é traduzido para PT‑BR.

## 🔒 Privacidade
- Tudo roda localmente (sem tráfego externo). O Ollama atende em `http://127.0.0.1:11434` por padrão.

## ❗ Troubleshooting
- **Conexão recusada**: rode `ollama run phi3:instruct` (o servidor sobe automaticamente).  
- **Modelo não encontrado**: garanta que o nome exato existe (`ollama list`, `ollama pull <modelo>`).  
- **Resposta sem JSON**: o script tenta parsear; se falhar, usa fallback do conteúdo. Reduza `MAX_CHARS_PER_ITEM`.

