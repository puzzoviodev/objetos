
---
# front matter YAML não deve ser traduzido
---

# Exemplo de Documento

Use `pip install django` para instalar. Em seguida, execute:

```
python manage.py migrate
python manage.py createsuperuser
```

No Django, o QuerySet é avaliado de forma lazy. Classes como APIView, ModelAdmin e UserCreationForm não devem ser traduzidas.

Módulos: django.contrib.auth, django.urls, rest_framework.serializers

Caminhos: /var/www/app/settings.py, C:\projetos\app\manage.py

JSON:
```json
{
  "DEBUG": true,
  "ALLOWED_HOSTS": ["localhost", "127.0.0.1"]
}
```

YAML:
```yaml
version: '3.9'
services:
  web:
    build: .
    command: python manage.py runserver 0.0.0.0:8000
```

Texto comum deve ser traduzido para o português.
