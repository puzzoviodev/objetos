# -*- coding: utf-8 -*-
"""
Script: traduz_md_ollama_v5.py
Objetivo: Traduzir um arquivo Markdown técnico (EN -> PT-BR) 100% local usando **Ollama** (LLM rodando
          em localhost), SEM enviar o arquivo para a nuvem. O script envia SOMENTE strings segmentadas
          para o endpoint local do Ollama, preservando código/termos/links/URLs/YAML via pré/pós-processamento.

Premissas:
  - Arquivo de origem "chumbado" no mesmo diretório: arquivoorigem.md
  - Saída: arquivoorigem.pt-BR.md
  - Você tem o Ollama instalado e um modelo local (ex.: phi3:instruct) disponível.

Requisitos:
  - Python 3.8+
  - requests

Uso:
  1) Instale e inicie o Ollama (localhost:11434). Faça pull do modelo (ex.: `ollama run phi3:instruct`).
  2) Defina .env (opcional): OLLAMA_HOST, LLM_MODEL, TEMPERATURE, MAX_CHARS_PER_ITEM.
  3) Coloque arquivoorigem.md ao lado do script.
  4) pip install -r requirements.txt
  5) python traduz_md_ollama_v5.py
"""

import os
import re
import json
import time
from typing import Dict, List, Tuple

import requests

# ----------------------------- CONFIG ----------------------------- #
SOURCE_FILE = "arquivoorigem.md"
TARGET_FILE = "arquivoorigem.pt-BR.md"
FROM_LANG = "en"
TO_LANG = "pt-BR"  # apenas para prompt

ENV_FILE = ".env"

# Ollama defaults
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
LLM_MODEL = os.environ.get("LLM_MODEL", "phi3:instruct")
TEMPERATURE = float(os.environ.get("TEMPERATURE", "0.2"))

# Limites práticos (chars) para evitar contexto muito grande
MAX_CHARS_PER_ITEM = int(os.environ.get("MAX_CHARS_PER_ITEM", "4000"))

# Batching: para LLM usamos 1 a 1; você pode paralelizar por processos externos

# Ativa heurísticas do "Modo Técnico"
MODO_TECNICO = True
PRESERVAR_ALT_IMAGENS = True

# Glossário padrão (adicional ao arquivo do usuário)
GLOSSARIO_PADRAO: List[str] = [
    # Python/Django
    "Python", "pip", "venv", "virtualenv", "requirements.txt", "setup.py", "pyproject.toml",
    "Django", "ASGI", "WSGI", "manage.py", "settings.py", "wsgi.py", "asgi.py",
    "QuerySet", "Model", "ModelAdmin", "APIView", "Serializer", "ORM", "Migrations",
    "urls.py", "views.py", "models.py", "forms.py", "admin.py",
    "middleware", "template", "context", "staticfiles", "Media", "AppConfig",
    # DRF / FastAPI / etc
    "DRF", "Django REST Framework", "OpenAPI", "Swagger", "Uvicorn", "Gunicorn",
    # Devops/arquivos
    "Nginx", "Apache", "Docker", "docker-compose.yaml", "docker-compose.yml",
    "systemd", "nginx.conf", "gunicorn.conf.py",
    # DB
    "PostgreSQL", "MySQL", "SQLite", "Redis", "MongoDB",
    # Conceitos técnicos
    "Middleware", "Query", "Fixture", "Slug", "UUID", "JWT", "JWTAuth", "OAuth2",
    # Outros
    "Bootstrap", "jQuery", "Webpack", "Node.js", "npm", "yarn",
]

GLOSSARY_FILE = "glossario_termos_nao_traduzir.txt"

# ------------------------- REGEX COMPILADAS ------------------------ #
RE_FENCE = re.compile(r"^(\s*)(`{3,}|~{3,})(.*)$")
RE_INLINE_CODE = re.compile(r"`[^`]*`")
RE_IMAGE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
RE_LINK = re.compile(r"(?<!!)\[([^\]]+)\]\(([^)]+)\)")
RE_BARE_URL = re.compile(r"(?<!\()(?P<url>https?://[^\s)]+)")
RE_YAML_DELIM = re.compile(r"^\s*---\s*$")

# Heurísticas Modo Técnico
RE_SNAKE = re.compile(r"\b[a-z][a-z0-9_]*_[a-z0-9_]+\b")
RE_CAMEL = re.compile(r"\b(?:[A-Z][a-z0-9]+){2,}[A-Za-z0-9]*\b")
RE_DOTTED = re.compile(r"\b[a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*)+\b")
RE_PATH = re.compile(r"(?:\b[A-Za-z]:\\[^\s]+|/[^\s]+(?:/[\w.\-]+)*)")
RE_CMD = re.compile(r"\b(?:pip|python3?|py|uv|poetry|pipenv)\s+[\w.\-/]+(?:\s+[\w.\-/]+)*\b")
RE_JSON_KEY = re.compile(r"\"([^\"]+)\"\s*:\s*")
RE_YAML_KEY = re.compile(r"^\s*([A-Za-z_][\w\-]*)\s*:\s*", re.MULTILINE)

# --------------------------- UTILITÁRIOS --------------------------- #

def load_env(path: str = ENV_FILE) -> None:
    if not os.path.isfile(path):
        return
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                k, v = line.split('=', 1)
                os.environ.setdefault(k.strip(), v.strip())


def load_glossary(path: str) -> List[str]:
    terms: List[str] = []
    if os.path.isfile(path):
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                t = line.strip()
                if t and not t.startswith('#'):
                    terms.append(t)
    seen = set()
    all_terms: List[str] = []
    for t in (terms + GLOSSARIO_PADRAO):
        if t not in seen:
            seen.add(t)
            all_terms.append(t)
    all_terms.sort(key=len, reverse=True)
    return all_terms

# -------------------------- PLACEHOLDERS --------------------------- #

def protect_with_regex(text: str, pattern: re.Pattern, bucket: Dict[str, str], tag: str) -> str:
    def _repl(m):
        key = f"__{tag}_{len(bucket)}__"
        bucket[key] = m.group(0)
        return key
    return pattern.sub(_repl, text)


def protect_inline_code(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        key = f"__CODE_{len(bucket)}__"
        bucket[key] = m.group(0)
        return key
    return RE_INLINE_CODE.sub(_repl, text)


def protect_images(text: str, bucket: Dict[str, str]) -> str:
    if PRESERVAR_ALT_IMAGENS:
        def _repl(m):
            key = f"__IMG_{len(bucket)}__"
            bucket[key] = m.group(0)
            return key
        return RE_IMAGE.sub(_repl, text)
    else:
        def _repl(m):
            alt, url = m.group(1), m.group(2)
            key = f"__IMGURL_{len(bucket)}__"
            bucket[key] = url
            return f"![{alt}]({key})"
        return RE_IMAGE.sub(_repl, text)


def extract_links(text: str, labels: List[str], urls: List[str]) -> str:
    def _repl(m):
        label = m.group(1)
        url = m.group(2)
        idx = len(labels)
        labels.append(label)
        urls.append(url)
        return f"__XREF_{idx}__"
    return RE_LINK.sub(_repl, text)


def protect_bare_urls(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        url = m.group("url")
        key = f"__URL_{len(bucket)}__"
        bucket[key] = url
        return key
    return RE_BARE_URL.sub(_repl, text)


def protect_terms(text: str, terms: List[str], bucket: Dict[str, str]) -> str:
    for term in terms:
        key = f"__TERM_{len(bucket)}__"
        bucket[key] = term
        if re.match(r"^[\w\-\.]+$", term):
            pattern = re.compile(rf"\b{re.escape(term)}\b")
        else:
            pattern = re.compile(re.escape(term))
        text = pattern.sub(key, text)
    return text


def restore_placeholders(text: str, bucket: Dict[str, str]) -> str:
    for key in sorted(bucket.keys(), key=len, reverse=True):
        text = text.replace(key, bucket[key])
    return text

# --------------------- SEGMENTAÇÃO EM PARÁGRAFOS --------------------- #

def split_into_paragraphs(lines: List[str]) -> List[List[str]]:
    paragraphs: List[List[str]] = []
    current: List[str] = []
    in_fence = False
    in_yaml = False
    yaml_started = False

    for line in lines:
        if not yaml_started and RE_YAML_DELIM.match(line):
            yaml_started = True
            in_yaml = True
            if current:
                paragraphs.append(current); current = []
            paragraphs.append([line])
            continue
        elif yaml_started and in_yaml and RE_YAML_DELIM.match(line):
            paragraphs.append([line])
            in_yaml = False
            continue
        elif in_yaml:
            paragraphs.append([line])
            continue

        m = RE_FENCE.match(line)
        if m:
            if not in_fence:
                if current:
                    paragraphs.append(current); current = []
                in_fence = True
                paragraphs.append([line])
            else:
                paragraphs.append([line])
                in_fence = False
            continue

        if in_fence:
            paragraphs.append([line])
            continue

        if line.strip() == "":
            if current:
                paragraphs.append(current); current = []
            paragraphs.append([line])
        else:
            current.append(line)

    if current:
        paragraphs.append(current)

    return paragraphs

# -------------------------- OLLAMA CALL -------------------------- #

SYSTEM_PROMPT = (
    "Você é um tradutor técnico EN→PT-BR. Regras OBRIGATÓRIAS:\n"
    "- Preserve a sintaxe Markdown.\n"
    "- NÃO traduza nada entre crases (`...`) nem blocos cercados (```...```).\n"
    "- NÃO traduza identificadores (CamelCase, snake_case), módulos.com.pontos, caminhos e URLs.\n"
    "- Preserve chaves JSON/YAML (\"key\":, key:).\n"
    "- Traduza SOMENTE o texto corrido.\n"
    "- Responda APENAS em JSON no formato: {\"translated\": \"...\"}."
)


def ollama_chat_once(host: str, model: str, system_prompt: str, user_content: str, temperature: float = 0.2, timeout: int = 120) -> str:
    """Chama o endpoint /api/chat do Ollama local e retorna o texto da mensagem final."""
    url = host.rstrip('/') + "/api/chat"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content}
        ],
        "options": {"temperature": temperature},
        "stream": False
    }
    r = requests.post(url, json=payload, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    # Formato: {"message": {"role": "assistant", "content": "..."}, ...}
    return data.get("message", {}).get("content", "")


def translate_chunk_with_ollama(text: str) -> str:
    """Envia um chunk de texto para o Ollama com instruções rígidas de resposta JSON."""
    content = f"Traduza de {FROM_LANG} para {TO_LANG} seguindo as regras. Texto:\n\n" + text
    raw = ollama_chat_once(OLLAMA_HOST, LLM_MODEL, SYSTEM_PROMPT, content, TEMPERATURE)
    # Tenta extrair JSON {"translated": "..."}
    translated = None
    # Primeiro, tenta JSON direto
    try:
        obj = json.loads(raw)
        translated = obj.get("translated")
    except Exception:
        pass
    if not translated:
        # Tenta achar um bloco JSON no meio do texto
        m = re.search(r"\{\s*\"translated\"\s*:\s*\"([\s\S]*?)\"\s*\}", raw)
        if m:
            translated = m.group(1)
        else:
            # Fallback: usa a resposta inteira (pode conter extra); última tentativa
            translated = raw
    return translated

# -------------------------- TRADUÇÃO TEXTO -------------------------- #

def translate_paragraph(paragraph: str, glossary_terms: List[str]) -> str:
    bucket: Dict[str, str] = {}
    labels: List[str] = []
    urls: List[str] = []

    # 1) Proteções
    stage = protect_images(paragraph, bucket)
    stage = protect_inline_code(stage, bucket)
    stage = protect_bare_urls(stage, bucket)
    stage = extract_links(stage, labels, urls)

    # 2) Heurísticas técnicas
    if MODO_TECNICO:
        stage = protect_with_regex(stage, RE_SNAKE, bucket, tag="SNAKE")
        stage = protect_with_regex(stage, RE_CAMEL, bucket, tag="CAMEL")
        stage = protect_with_regex(stage, RE_DOTTED, bucket, tag="MOD")
        stage = protect_with_regex(stage, RE_PATH, bucket, tag="PATH")
        stage = protect_with_regex(stage, RE_CMD, bucket, tag="CMD")
        def _repl_json(m):
            k = f"__JKEY_{len(bucket)}__"; bucket[k] = m.group(0); return k
        stage = RE_JSON_KEY.sub(_repl_json, stage)
        def _repl_yaml(m):
            k = f"__YKEY_{len(bucket)}__"; bucket[k] = m.group(0); return k
        stage = RE_YAML_KEY.sub(_repl_yaml, stage)

    # 3) Glossário
    stage = protect_terms(stage, glossary_terms, bucket)

    # 4) Tradução (quebra se necessário)
    if len(stage) > MAX_CHARS_PER_ITEM:
        parts = re.split(r"(\.|!|\?|;)(\s+)", stage)
        buf = ""; chunks = []
        for piece in parts:
            if len(buf) + len(piece) <= MAX_CHARS_PER_ITEM:
                buf += piece
            else:
                if buf:
                    chunks.append(buf)
                buf = piece
        if buf:
            chunks.append(buf)
        translated_chunks: List[str] = []
        for ch in chunks:
            translated_chunks.append(translate_chunk_with_ollama(ch))
        translated = "".join(translated_chunks)
    else:
        translated = translate_chunk_with_ollama(stage)

    # 5) (Se houver links) — labels são curtas: podemos ignorar tradução aqui porque o parágrafo já foi traduzido
    # Caso queira resultado ainda melhor, poderíamos traduzir labels separadamente, mas LLM costuma lidar bem.
    for i, url_orig in enumerate(urls):
        # Se o placeholder permaneceu, simplesmente restaura abaixo ao final.
        pass

    # 6) Restaurar placeholders
    translated = restore_placeholders(translated, bucket)
    return translated


def process_markdown(lines: List[str], glossary_terms: List[str]) -> List[str]:
    out_lines: List[str] = []
    paragraphs = split_into_paragraphs(lines)

    in_yaml = False
    yaml_started = False

    total_chars = sum(len("".join(p)) for p in paragraphs)
    translated_chars = 0
    t0 = time.time()

    for block in paragraphs:
        if len(block) == 1 and RE_YAML_DELIM.match(block[0]):
            out_lines.append(block[0])
            if not yaml_started:
                yaml_started = True; in_yaml = True
            else:
                in_yaml = False
            continue

        if in_yaml:
            out_lines.extend(block)
            continue

        if len(block) == 1 and (RE_FENCE.match(block[0]) or block[0].strip() == ""):
            out_lines.append(block[0])
            continue

        paragraph_text = "".join(block)
        translated_chars += len(paragraph_text)
        out_lines.append(translate_paragraph(paragraph_text, glossary_terms))

        elapsed = time.time() - t0
        speed = (translated_chars / elapsed) if elapsed > 0 else 0
        pct = (translated_chars / total_chars) * 100 if total_chars > 0 else 100
        print(f"[Ollama V5] {pct:6.2f}% | {translated_chars}/{total_chars} chars | {speed:,.0f} chars/s | {elapsed:,.1f}s", end='\r')

    print()
    return out_lines


# ------------------------------- MAIN ------------------------------- #

def main():
    load_env()  # carrega .env se existir

    # Recarrega configurações após .env (permite override)
    global OLLAMA_HOST, LLM_MODEL, TEMPERATURE, MAX_CHARS_PER_ITEM
    OLLAMA_HOST = os.environ.get("OLLAMA_HOST", OLLAMA_HOST)
    LLM_MODEL = os.environ.get("LLM_MODEL", LLM_MODEL)
    TEMPERATURE = float(os.environ.get("TEMPERATURE", str(TEMPERATURE)))
    MAX_CHARS_PER_ITEM = int(os.environ.get("MAX_CHARS_PER_ITEM", str(MAX_CHARS_PER_ITEM)))

    glossary_terms = load_glossary(GLOSSARY_FILE)
    print(f"Glossário ativo: {len(glossary_terms)} termo(s) (arquivo + padrão). Modelo: {LLM_MODEL}")

    if not os.path.isfile(SOURCE_FILE):
        raise FileNotFoundError(f"Arquivo '{SOURCE_FILE}' não encontrado em {os.getcwd()}")

    with open(SOURCE_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()

    print(f"Conectando ao Ollama em {OLLAMA_HOST} e traduzindo segmentos localmente...")
    t0 = time.time()
    out_lines = process_markdown(lines, glossary_terms)
    dt = time.time() - t0

    with open(TARGET_FILE, 'w', encoding='utf-8', newline='') as f:
        f.writelines(out_lines)

    total = sum(len(l) for l in lines)
    print("\nConcluído!")
    print(f"Arquivo gerado: {TARGET_FILE}")
    print(f"Tamanho original: {total:,} caracteres | Tempo: {dt:,.1f}s | Vazão: {total/dt:,.0f} chars/s" if dt>0 else "")

if __name__ == '__main__':
    main()
