
# Tradução Técnica de Markdown (EN → PT‑BR) com **Microsoft Translator (Azure)** — V3

Este pacote traduz **`arquivoorigem.md`** para **português (Brasil)** usando a **API do Azure Translator**,
**sem enviar o arquivo**: apenas **strings segmentadas** são transmitidas; todo o pré/pós-processamento
(preservação de código/termos/links/URLs/YAML) ocorre **localmente**.

> **Privacidade:** A API empresarial do Microsoft Translator aplica política **No Trace**: as chamadas
> não são persistidas e não são usadas para treinamento de modelos. Consulte: No‑Trace e diretrizes de
> dados/privacidade da Microsoft. 

---

## 📦 Conteúdo
- `traduz_md_azure_v3.py` — script principal (Azure Translator v3, com heurísticas do **Modo Técnico**)
- `.env.example` — modelo para configurar `AZURE_TRANSLATOR_KEY` e `AZURE_TRANSLATOR_REGION`
- `glossario_termos_nao_traduzir.txt` — **opcional**, já com termos comuns (edite/complete)
- `exemplos_teste.md` — arquivo de teste rápido

---

## 🚀 Passo a passo

### 1) Criar o recurso **Azure Translator**
1. Acesse o **Azure Portal** → *Create a resource* → **Translator** (Azure Cognitive Services).
2. Em *Keys and Endpoint*, copie:
   - **Key** (Subscription Key)
   - **Region** (por ex.: `eastus`, `brazilsouth`, etc.)

> **Referências oficiais (privacidade e No‑Trace):**
> - **No Trace – Microsoft Translator for Business** (API não persiste conteúdo; sem uso para treinamento).  
> - **Data, privacy, and security for Azure Translator** (detalhes de processamento/armazenamento temporário em Document Translation vs Text Translation).

### 2) Configurar variáveis
Crie um arquivo `.env` (no mesmo diretório) baseado em `.env.example`:
```ini
AZURE_TRANSLATOR_KEY=coloque_sua_chave_aqui
AZURE_TRANSLATOR_REGION=coloque_sua_regiao_aqui  # ex.: eastus
```

### 3) Dependências
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install requests
```

### 4) Coloque os arquivos
- `arquivoorigem.md` (o Markdown em inglês a ser traduzido) ao lado do script.
- (Opcional) Ajuste termos em `glossario_termos_nao_traduzir.txt`.

### 5) Executar
```bash
python traduz_md_azure_v3.py
```
Saída: `arquivoorigem.pt-BR.md`.

---

## 🔒 Como garantimos que **código/termos técnicos** não sejam traduzidos
O script usa o **Modo Técnico** (regex + placeholders) para **congelar**:
- Blocos de código (```/~~~) e **inline code** (`` `assim` ``)
- **Links** (tradução só do rótulo; URL intacta) e **imagens** (ALT preservado por padrão)
- **URLs** soltas
- **Chaves JSON/YAML** (`"DEBUG":`, `ALLOWED_HOSTS:`)
- **Identificadores**: `snake_case`, `Camel/PascalCase` (`ModelAdmin`, `APIView`, `QuerySet`)
- **Módulos dotted** (`django.contrib.auth`), **caminhos** (`/var/www/app`, `C:\projetos\app`)
- **Comandos** (`pip install`, `python manage.py migrate`)
- **Glossário**: nomes de libs, arquivos e termos que você quiser **não traduzir** (arquivo + padrão)

> **Dica:** Se um termo **deve** ser traduzido (ex.: “Model” → “Modelo” **quando não for** uma classe), **não** o inclua no glossário.

---

## 🧪 Teste rápido
Traduza `exemplos_teste.md` e confirme que identificadores/código permanecem intactos e o texto corrido foi traduzido.

---

## ℹ️ Notas importantes
- **Não enviamos o arquivo** para a API, apenas **strings de texto** pós-máscara.
- Use **endpoints e rede privada** (Private Link) e *key vault* se precisar de isolamento adicional em produção.
- Em caso de **429/5xx**, o script faz **retries com backoff**.

---

## 📚 Referências oficiais
- **No Trace – Microsoft Translator for Business** (sem persistência/treino para chamadas da API).  
- **Data/Privacy/Security – Azure Translator** (detalhes de processamento/armazenamento temporário para Document vs Text Translation).  
