# -*- coding: utf-8 -*-
"""
Script: traduz_md_azure_v3.py
Objetivo: Traduzir um arquivo Markdown técnico (EN -> PT-BR) usando **Microsoft Translator (Azure)**,
          sem enviar o arquivo bruto: apenas **segmentos de texto** são enviados à API, e toda a
          preservação de código/termos/links/URLs/YAML é feita **localmente** (pré e pós-processamento).

Premissas:
  - O arquivo de origem está "chumbado" no mesmo diretório com o nome: arquivoorigem.md
  - O arquivo de saída será: arquivoorigem.pt-BR.md
  - Você cria um recurso **Azure Translator** e define as variáveis de ambiente (ou .env):
      AZURE_TRANSLATOR_KEY, AZURE_TRANSLATOR_REGION

Privacidade:
  - A API do Azure Translator possui política **No Trace** (chamadas de API não são persistidas
    nem usadas para treinamento). Consulte a documentação oficial. 

Requisitos:
  - Python 3.8+
  - requests (para chamadas HTTP)

Uso:
  1) Ajuste/defina AZURE_TRANSLATOR_KEY e AZURE_TRANSLATOR_REGION (env ou .env ao lado do script).
  2) Coloque arquivoorigem.md ao lado do script.
  3) pip install requests
  4) python traduz_md_azure_v3.py

"""

import os
import re
import json
import time
import random
from typing import Dict, List, Tuple

import requests

# ----------------------------- CONFIG ----------------------------- #
SOURCE_FILE = "arquivoorigem.md"          # arquivo de entrada
TARGET_FILE = "arquivoorigem.pt-BR.md"    # arquivo de saída
FROM_LANG = "en"
TO_LANG = "pt"                            # pt cobre pt-BR no contexto de tradução

# Carregar credenciais do ambiente ou de um arquivo .env (simples)
ENV_FILE = ".env"

API_BASE = "https://api.cognitive.microsofttranslator.com"
API_PATH = "/translate"
API_VERSION = "3.0"

# Lotes e limites
BATCH_SIZE = 50           # máximo de itens por request
MAX_CHARS_PER_ITEM = 4500 # margem segura (limites de payload/segmento da API)
MAX_RETRIES = 5
BACKOFF_BASE = 0.8

# Ativa heurísticas do "Modo Técnico" (como na V2 offline)
MODO_TECNICO = True
PRESERVAR_ALT_IMAGENS = True

# Glossário padrão (adicional ao arquivo do usuário)
GLOSSARIO_PADRAO: List[str] = [
    # Python/Django
    "Python", "pip", "venv", "virtualenv", "requirements.txt", "setup.py", "pyproject.toml",
    "Django", "ASGI", "WSGI", "manage.py", "settings.py", "wsgi.py", "asgi.py",
    "QuerySet", "Model", "ModelAdmin", "APIView", "Serializer", "ORM", "Migrations",
    "urls.py", "views.py", "models.py", "forms.py", "admin.py",
    "middleware", "template", "context", "staticfiles", "Media", "AppConfig",
    # DRF / FastAPI / etc
    "DRF", "Django REST Framework", "OpenAPI", "Swagger", "Uvicorn", "Gunicorn",
    # Devops/arquivos
    "Nginx", "Apache", "Docker", "docker-compose.yaml", "docker-compose.yml",
    "systemd", "nginx.conf", "gunicorn.conf.py",
    # DB
    "PostgreSQL", "MySQL", "SQLite", "Redis", "MongoDB",
    # Conceitos técnicos
    "Middleware", "Query", "Fixture", "Slug", "UUID", "JWT", "JWTAuth", "OAuth2",
    # Outros
    "Bootstrap", "jQuery", "Webpack", "Node.js", "npm", "yarn",
]

# Nome do arquivo de glossário do usuário
GLOSSARY_FILE = "glossario_termos_nao_traduzir.txt"

# ------------------------- REGEX COMPILADAS ------------------------ #
RE_FENCE = re.compile(r"^(\s*)(`{3,}|~{3,})(.*)$")
RE_INLINE_CODE = re.compile(r"`[^`]*`")
RE_IMAGE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
RE_LINK = re.compile(r"(?<!!)\[([^\]]+)\]\(([^)]+)\)")
RE_BARE_URL = re.compile(r"(?<!\()(?P<url>https?://[^\s)]+)")
RE_YAML_DELIM = re.compile(r"^\s*---\s*$")

# Heurísticas Modo Técnico
RE_SNAKE = re.compile(r"\b[a-z][a-z0-9_]*_[a-z0-9_]+\b")
RE_CAMEL = re.compile(r"\b(?:[A-Z][a-z0-9]+){2,}[A-Za-z0-9]*\b")
RE_DOTTED = re.compile(r"\b[a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*)+\b")
RE_PATH = re.compile(r"(?:\b[A-Za-z]:\\[^\s]+|/[^\s]+(?:/[\w.\-]+)*)")
RE_CMD = re.compile(r"\b(?:pip|python3?|py|uv|poetry|pipenv)\s+[\w.\-/]+(?:\s+[\w.\-/]+)*\b")
RE_JSON_KEY = re.compile(r"\"([^\"]+)\"\s*:\s*")
RE_YAML_KEY = re.compile(r"^\s*([A-Za-z_][\w\-]*)\s*:\s*", re.MULTILINE)

# --------------------------- UTILITÁRIOS --------------------------- #

def load_env(path: str = ENV_FILE) -> None:
    """Carrega variáveis simples de um arquivo .env (chave=valor), sem dependências."""
    if not os.path.isfile(path):
        return
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                k, v = line.split('=', 1)
                os.environ.setdefault(k.strip(), v.strip())


def get_azure_credentials() -> Tuple[str, str]:
    load_env()
    key = os.environ.get('AZURE_TRANSLATOR_KEY')
    region = os.environ.get('AZURE_TRANSLATOR_REGION')
    if not key or not region:
        raise RuntimeError(
            "Defina AZURE_TRANSLATOR_KEY e AZURE_TRANSLATOR_REGION em variáveis de ambiente ou .env"
        )
    return key, region


def load_glossary(path: str) -> List[str]:
    terms: List[str] = []
    if os.path.isfile(path):
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                t = line.strip()
                if t and not t.startswith('#'):
                    terms.append(t)
    # mescla com padrão e remove duplicatas
    seen = set()
    all_terms: List[str] = []
    for t in (terms + GLOSSARIO_PADRAO):
        if t not in seen:
            seen.add(t)
            all_terms.append(t)
    all_terms.sort(key=len, reverse=True)
    return all_terms

# -------------------------- PLACEHOLDERS --------------------------- #

def protect_with_regex(text: str, pattern: re.Pattern, bucket: Dict[str, str], tag: str) -> str:
    def _repl(m):
        key = f"__{tag}_{len(bucket)}__"
        bucket[key] = m.group(0)
        return key
    return pattern.sub(_repl, text)


def protect_inline_code(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        key = f"__CODE_{len(bucket)}__"
        bucket[key] = m.group(0)
        return key
    return RE_INLINE_CODE.sub(_repl, text)


def protect_images(text: str, bucket: Dict[str, str]) -> str:
    if PRESERVAR_ALT_IMAGENS:
        def _repl(m):
            key = f"__IMG_{len(bucket)}__"
            bucket[key] = m.group(0)
            return key
        return RE_IMAGE.sub(_repl, text)
    else:
        def _repl(m):
            alt, url = m.group(1), m.group(2)
            key = f"__IMGURL_{len(bucket)}__"
            bucket[key] = url
            return f"![{alt}]({key})"
        return RE_IMAGE.sub(_repl, text)


def extract_links(text: str, labels: List[str], urls: List[str]) -> str:
    def _repl(m):
        label = m.group(1)
        url = m.group(2)
        idx = len(labels)
        labels.append(label)
        urls.append(url)
        return f"__XREF_{idx}__"
    return RE_LINK.sub(_repl, text)


def protect_bare_urls(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        url = m.group("url")
        key = f"__URL_{len(bucket)}__"
        bucket[key] = url
        return key
    return RE_BARE_URL.sub(_repl, text)


def protect_terms(text: str, terms: List[str], bucket: Dict[str, str]) -> str:
    for term in terms:
        key = f"__TERM_{len(bucket)}__"
        bucket[key] = term
        if re.match(r"^[\w\-\.]+$", term):
            pattern = re.compile(rf"\b{re.escape(term)}\b")
        else:
            pattern = re.compile(re.escape(term))
        text = pattern.sub(key, text)
    return text


def restore_placeholders(text: str, bucket: Dict[str, str]) -> str:
    for key in sorted(bucket.keys(), key=len, reverse=True):
        text = text.replace(key, bucket[key])
    return text

# -------------------- SEGMENTAÇÃO / AGRUPAMENTO -------------------- #

def split_into_paragraphs(lines: List[str]) -> List[List[str]]:
    paragraphs: List[List[str]] = []
    current: List[str] = []
    in_fence = False
    in_yaml = False
    yaml_started = False

    for line in lines:
        if not yaml_started and RE_YAML_DELIM.match(line):
            yaml_started = True
            in_yaml = True
            if current:
                paragraphs.append(current); current = []
            paragraphs.append([line]);
            continue
        elif yaml_started and in_yaml and RE_YAML_DELIM.match(line):
            paragraphs.append([line])
            in_yaml = False
            continue
        elif in_yaml:
            paragraphs.append([line])
            continue

        m = RE_FENCE.match(line)
        if m:
            if not in_fence:
                if current:
                    paragraphs.append(current); current = []
                in_fence = True
                paragraphs.append([line])
            else:
                paragraphs.append([line])
                in_fence = False
            continue

        if in_fence:
            paragraphs.append([line])
            continue

        if line.strip() == "":
            if current:
                paragraphs.append(current); current = []
            paragraphs.append([line])
        else:
            current.append(line)

    if current:
        paragraphs.append(current)

    return paragraphs


# ---------------------------- AZURE CALL ---------------------------- #

def azure_translate_batch(texts: List[str], key: str, region: str) -> List[str]:
    """Traduz uma lista de strings (até BATCH_SIZE) via Azure Translator.
       Retorna a lista de traduções na mesma ordem.
    """
    if not texts:
        return []

    url = f"{API_BASE}{API_PATH}?api-version={API_VERSION}&from={FROM_LANG}&to={TO_LANG}"
    headers = {
        'Ocp-Apim-Subscription-Key': key,
        'Ocp-Apim-Subscription-Region': region,
        'Content-Type': 'application/json; charset=utf-8'
    }
    body = [{"text": t} for t in texts]

    # Retry com backoff exponencial para 429/5xx
    attempt = 0
    while True:
        try:
            resp = requests.post(url, headers=headers, data=json.dumps(body), timeout=30)
            if resp.status_code == 200:
                data = resp.json()
                out = []
                for item in data:
                    # estrutura: [{"translations": [{"text": "...", "to": "pt"}]}]
                    trans = item.get('translations', [])
                    out.append(trans[0]['text'] if trans else "")
                return out
            elif resp.status_code in (429, 500, 503):
                attempt += 1
                if attempt > MAX_RETRIES:
                    raise RuntimeError(f"Falha após {MAX_RETRIES} tentativas: HTTP {resp.status_code} => {resp.text[:300]}")
                delay = (BACKOFF_BASE ** attempt) * (1.0 + random.random())
                time.sleep(delay)
            else:
                raise RuntimeError(f"Erro HTTP {resp.status_code}: {resp.text[:300]}")
        except requests.RequestException as e:
            attempt += 1
            if attempt > MAX_RETRIES:
                raise
            delay = (BACKOFF_BASE ** attempt) * (1.0 + random.random())
            time.sleep(delay)


# -------------------------- TRADUÇÃO TEXTO -------------------------- #

def translate_paragraph(paragraph: str, key: str, region: str, glossary_terms: List[str]) -> str:
    bucket: Dict[str, str] = {}
    labels: List[str] = []
    urls: List[str] = []

    # 1) Proteções
    stage = protect_images(paragraph, bucket)
    stage = protect_inline_code(stage, bucket)
    stage = protect_bare_urls(stage, bucket)
    stage = extract_links(stage, labels, urls)

    # 2) Heurísticas técnicas
    if MODO_TECNICO:
        stage = protect_with_regex(stage, RE_SNAKE, bucket, tag="SNAKE")
        stage = protect_with_regex(stage, RE_CAMEL, bucket, tag="CAMEL")
        stage = protect_with_regex(stage, RE_DOTTED, bucket, tag="MOD")
        stage = protect_with_regex(stage, RE_PATH, bucket, tag="PATH")
        stage = protect_with_regex(stage, RE_CMD, bucket, tag="CMD")
        def _repl_json(m):
            k = f"__JKEY_{len(bucket)}__"; bucket[k] = m.group(0); return k
        stage = RE_JSON_KEY.sub(_repl_json, stage)
        def _repl_yaml(m):
            k = f"__YKEY_{len(bucket)}__"; bucket[k] = m.group(0); return k
        stage = RE_YAML_KEY.sub(_repl_yaml, stage)

    # 3) Glossário
    stage = protect_terms(stage, glossary_terms, bucket)

    # 4) Traduzir labels de links separadamente
    if labels:
        labels_pt = []
        # dividir labels em lotes menores (robustez)
        for i in range(0, len(labels), BATCH_SIZE):
            batch = labels[i:i+BATCH_SIZE]
            labels_pt.extend(azure_translate_batch(batch, key, region))
    else:
        labels_pt = []

    # 5) Traduzir o parágrafo
    # Toma cuidado com comprimento máximo
    if len(stage) > MAX_CHARS_PER_ITEM:
        # quebra por sentenças aproximadas (por pontuação). fallback simples
        parts = re.split(r"(\.|!|\?|;)(\s+)", stage)
        buffer = ""; chunks = []
        for piece in parts:
            if len(buffer) + len(piece) <= MAX_CHARS_PER_ITEM:
                buffer += piece
            else:
                if buffer:
                    chunks.append(buffer)
                buffer = piece
        if buffer:
            chunks.append(buffer)
        translated_chunks: List[str] = []
        for i in range(0, len(chunks), BATCH_SIZE):
            translated_chunks.extend(azure_translate_batch(chunks[i:i+BATCH_SIZE], key, region))
        translated = "".join(translated_chunks)
    else:
        translated = azure_translate_batch([stage], key, region)[0]

    # 6) Reconstituir links
    for i, (lab_pt, url_orig) in enumerate(zip(labels_pt, urls)):
        translated = translated.replace(f"__XREF_{i}__", f"[{lab_pt}]({url_orig})")

    # 7) Restaurar placeholders
    translated = restore_placeholders(translated, bucket)
    return translated


def process_markdown(lines: List[str], key: str, region: str, glossary_terms: List[str]) -> List[str]:
    out_lines: List[str] = []
    paragraphs = split_into_paragraphs(lines)

    in_yaml = False
    yaml_started = False

    total_chars = sum(len("".join(p)) for p in paragraphs)
    translated_chars = 0
    t0 = time.time()

    for block in paragraphs:
        if len(block) == 1 and RE_YAML_DELIM.match(block[0]):
            out_lines.append(block[0])
            if not yaml_started:
                yaml_started = True; in_yaml = True
            else:
                in_yaml = False
            continue

        if in_yaml:
            out_lines.extend(block)
            continue

        if len(block) == 1 and (RE_FENCE.match(block[0]) or block[0].strip() == ""):
            out_lines.append(block[0])
            continue

        paragraph_text = "".join(block)
        translated_chars += len(paragraph_text)
        out_lines.append(translate_paragraph(paragraph_text, key, region, glossary_terms))

        elapsed = time.time() - t0
        speed = (translated_chars / elapsed) if elapsed > 0 else 0
        pct = (translated_chars / total_chars) * 100 if total_chars > 0 else 100
        print(f"[Azure V3] {pct:6.2f}% | {translated_chars}/{total_chars} chars | {speed:,.0f} chars/s | {elapsed:,.1f}s", end='\r')

    print()
    return out_lines


# ------------------------------- MAIN ------------------------------- #

def main():
    key, region = get_azure_credentials()

    glossary_terms = load_glossary(GLOSSARY_FILE)
    print(f"Glossário ativo: {len(glossary_terms)} termo(s) (arquivo + padrão). Modo Técnico: {MODO_TECNICO}")

    if not os.path.isfile(SOURCE_FILE):
        raise FileNotFoundError(f"Arquivo '{SOURCE_FILE}' não encontrado em {os.getcwd()}")

    with open(SOURCE_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()

    print("Iniciando tradução (online: Azure Translator), enviando apenas strings segmentadas...")
    t0 = time.time()
    out_lines = process_markdown(lines, key, region, glossary_terms)
    dt = time.time() - t0

    with open(TARGET_FILE, 'w', encoding='utf-8', newline='') as f:
        f.writelines(out_lines)

    total = sum(len(l) for l in lines)
    print("\nConcluído!")
    print(f"Arquivo gerado: {TARGET_FILE}")
    print(f"Tamanho original: {total:,} caracteres | Tempo: {dt:,.1f}s | Vazão: {total/dt:,.0f} chars/s" if dt>0 else "")

if __name__ == '__main__':
    main()
