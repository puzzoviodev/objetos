# -*- coding: utf-8 -*-
"""
Script: traduz_md_local.py
Objetivo: Traduzir um arquivo Markdown técnico (EN -> PT-BR) 100% local usando Argos Translate,
          preservando estrutura (cabeçalhos, listas, links, URLs, imagens) e, crucialmente,
          deixando blocos de código (fenced) e códigos inline intocados.

Requisitos:
  - Python 3.8+
  - pip install argostranslate
  - Modelo Argos .argosmodel para EN->PT (ex.: en_pt.argosmodel) disponível LOCALMENTE
    no mesmo diretório do script para operação totalmente offline.

Como usar:
  1) Coloque este script e o arquivo 'arquivoorigem.md' no mesmo diretório.
  2) (Opcional, porém recomendado para 100% offline) Coloque também 'en_pt.argosmodel' no mesmo diretório.
  3) Execute: python traduz_md_local.py
  4) Arquivo traduzido: 'arquivoorigem.pt-BR.md'

Observações:
  - O script contém comentários detalhados para facilitar manutenção.
  - Há suporte opcional a um glossário de termos que NÃO devem ser traduzidos.
    Basta criar um arquivo 'glossario_termos_nao_traduzir.txt' (um termo por linha).
"""

import os
import re
import time
from typing import Dict, List

from argostranslate import package as argos_package
from argostranslate import translate as argos_translate

# ----------------------------- CONFIG ----------------------------- #
SOURCE_FILE = "arquivoorigem.md"         # arquivo de entrada (mesmo diretório)
TARGET_FILE = "arquivoorigem.pt-BR.md"   # arquivo de saída
FROM_LANG = "en"                         # código origem
TO_LANG = "pt"                           # código destino (pt cobre pt-BR no Argos)
LOCAL_MODEL_FILENAME = "en_pt.argosmodel"# pacote local do modelo Argos
GLOSSARY_FILE = "glossario_termos_nao_traduzir.txt"  # opcional

# ------------------------- REGEX COMPILADAS ------------------------ #
RE_FENCE = re.compile(r"^(\s*)(`{3,}|~{3,})(.*)$")          # fences ``` ou ~~~
RE_INLINE_CODE = re.compile(r"`[^`]*`")                       # `inline`
RE_IMAGE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")         # ![alt](url)
RE_LINK = re.compile(r"(?<!!)\[([^\]]+)\]\(([^)]+)\)")     # [label](url)
RE_BARE_URL = re.compile(r"(?<!\()(?P<url>https?://[^\s)]+)")# URLs soltas
RE_YAML_DELIM = re.compile(r"^\s*---\s*$")                  # front-matter YAML

# --------------------------- UTILITÁRIOS --------------------------- #

def ensure_local_model_installed(from_code: str, to_code: str, local_model_filename: str) -> None:
    """Garante o modelo Argos EN->PT instalado a partir de arquivo local (.argosmodel)."""
    installed_langs = argos_translate.get_installed_languages()
    for lang_from in installed_langs:
        if lang_from.code == from_code:
            for possible_to in lang_from.translations:
                if possible_to.to_language.code == to_code:
                    return  # já instalado

    local_model_path = os.path.join(os.getcwd(), local_model_filename)
    if not os.path.isfile(local_model_path):
        raise FileNotFoundError(
            f"Modelo Argos '{local_model_filename}' não encontrado no diretório atual.\n"
            f"Para operar 100% offline, baixe previamente o pacote EN->PT (.argosmodel) e coloque-o ao lado do script.\n"
            f"Nome esperado: {local_model_filename}"
        )
    argos_package.install_from_path(local_model_path)


def get_translator(from_code: str, to_code: str):
    """Retorna objeto tradutor Argos para from_code -> to_code."""
    installed_langs = argos_translate.get_installed_languages()
    from_lang = next((l for l in installed_langs if l.code == from_code), None)
    to_lang = next((l for l in installed_langs if l.code == to_code), None)
    if from_lang is None or to_lang is None:
        raise RuntimeError("Idiomas não encontrados no Argos Translate após instalação do modelo.")
    return from_lang.get_translation(to_lang)


def load_glossary_terms(path: str) -> List[str]:
    """Carrega termos do glossário (um por linha). Linhas vazias ou começando com '#' são ignoradas."""
    if not os.path.isfile(path):
        return []
    terms: List[str] = []
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            t = line.strip()
            if not t or t.startswith('#'):
                continue
            terms.append(t)
    # Ordena por tamanho decrescente para evitar sobreposição de termos menores dentro de maiores
    terms.sort(key=len, reverse=True)
    return terms


def _escape_re(s: str) -> str:
    return re.escape(s)


def protect_terms(text: str, terms: List[str], bucket: Dict[str, str]) -> str:
    """Protege termos do glossário substituindo por placeholders __TERM_i__ (case sensitive)."""
    if not terms:
        return text

    # Evita substituir dentro de placeholders já existentes (__XREF__, __CODE__, etc.)
    # Assumimos que placeholders usam padrão __[A-Z]+_\d+__ e não colidem com termos.

    for term in terms:
        # placeholder único por termo e índice (não persistido entre parágrafos)
        key = f"__TERM_{len(bucket)}__"
        bucket[key] = term
        # Usa word boundaries quando o termo aparenta ser palavra simples; senão substitui literal
        # Critério simples: se contém apenas letras/dígitos/underscore, usa \b
        if re.match(r"^[\w-]+$", term, flags=re.UNICODE):
            pattern = re.compile(rf"\b{_escape_re(term)}\b")
        else:
            pattern = re.compile(_escape_re(term))
        text = pattern.sub(key, text)
    return text


def protect_inline_code(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        key = f"__CODE_{len(bucket)}__"
        bucket[key] = m.group(0)
        return key
    return RE_INLINE_CODE.sub(_repl, text)


def protect_images(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        key = f"__IMG_{len(bucket)}__"
        bucket[key] = m.group(0)
        return key
    return RE_IMAGE.sub(_repl, text)


def extract_links(text: str, labels: List[str], urls: List[str]) -> str:
    def _repl(m):
        label = m.group(1)
        url = m.group(2)
        idx = len(labels)
        labels.append(label)
        urls.append(url)
        return f"__XREF_{idx}__"
    return RE_LINK.sub(_repl, text)


def protect_bare_urls(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        url = m.group("url")
        key = f"__URL_{len(bucket)}__"
        bucket[key] = url
        return key
    return RE_BARE_URL.sub(_repl, text)


def restore_placeholders(text: str, bucket: Dict[str, str]) -> str:
    for key in sorted(bucket.keys(), key=len, reverse=True):
        text = text.replace(key, bucket[key])
    return text


def split_into_paragraphs(lines: List[str]) -> List[List[str]]:
    paragraphs: List[List[str]] = []
    current: List[str] = []
    in_fence = False
    in_yaml = False
    yaml_started = False

    for line in lines:
        # YAML front-matter
        if not yaml_started and RE_YAML_DELIM.match(line):
            yaml_started = True
            in_yaml = True
            if current:
                paragraphs.append(current)
                current = []
            paragraphs.append([line])
            continue
        elif yaml_started and in_yaml and RE_YAML_DELIM.match(line):
            paragraphs.append([line])
            in_yaml = False
            continue
        elif in_yaml:
            paragraphs.append([line])
            continue

        # Fences de código
        m = RE_FENCE.match(line)
        if m:
            if not in_fence:
                if current:
                    paragraphs.append(current)
                    current = []
                in_fence = True
                paragraphs.append([line])
            else:
                paragraphs.append([line])
                in_fence = False
            continue

        if in_fence:
            paragraphs.append([line])
            continue

        # Texto normal / quebras
        if line.strip() == "":
            if current:
                paragraphs.append(current)
                current = []
            paragraphs.append([line])
        else:
            current.append(line)

    if current:
        paragraphs.append(current)

    return paragraphs


def translate_paragraph(paragraph: str, translator, glossary_terms: List[str]) -> str:
    bucket: Dict[str, str] = {}
    labels: List[str] = []
    urls: List[str] = []

    # 1) Proteger imagens, códigos inline, URLs, e extrair links
    stage = protect_images(paragraph, bucket)
    stage = protect_inline_code(stage, bucket)
    stage = protect_bare_urls(stage, bucket)
    stage = extract_links(stage, labels, urls)

    # 2) Proteger termos do glossário (não traduzir)
    stage = protect_terms(stage, glossary_terms, bucket)

    # 3) Traduzir labels de links separadamente
    translated_labels: List[str] = []
    for label in labels:
        translated_labels.append(translator.translate(label))

    # 4) Traduzir o parágrafo restante
    translated = translator.translate(stage)

    # 5) Recolocar links
    for i, (lab_pt, url_orig) in enumerate(zip(translated_labels, urls)):
        translated = translated.replace(f"__XREF_{i}__", f"[{lab_pt}]({url_orig})")

    # 6) Restaurar placeholders (inclui termos do glossário, imagens, código, URLs)
    translated = restore_placeholders(translated, bucket)
    return translated


def process_markdown(lines: List[str], translator, glossary_terms: List[str]) -> List[str]:
    output_lines: List[str] = []
    paragraphs = split_into_paragraphs(lines)

    in_yaml = False
    yaml_started = False

    total_chars = sum(len("".join(p)) for p in paragraphs)
    translated_chars = 0
    t0 = time.time()

    for block in paragraphs:
        if len(block) == 1 and RE_YAML_DELIM.match(block[0]):
            line = block[0]
            output_lines.append(line)
            if not yaml_started:
                yaml_started = True
                in_yaml = True
            else:
                in_yaml = False
            continue

        if in_yaml:
            output_lines.extend(block)
            continue

        if len(block) == 1 and (RE_FENCE.match(block[0]) or block[0].strip() == ""):
            output_lines.append(block[0])
            continue

        paragraph_text = "".join(block)
        translated_chars += len(paragraph_text)
        translated_paragraph = translate_paragraph(paragraph_text, translator, glossary_terms)
        output_lines.append(translated_paragraph)

        elapsed = time.time() - t0
        speed = (translated_chars / elapsed) if elapsed > 0 else 0.0
        pct = (translated_chars / total_chars) * 100 if total_chars > 0 else 100.0
        print(f"[{pct:6.2f}%] {translated_chars}/{total_chars} chars | {speed:,.0f} chars/s | {elapsed:,.1f}s", end="\r")

    print()
    return output_lines


def main():
    # 1) Modelo local
    ensure_local_model_installed(FROM_LANG, TO_LANG, LOCAL_MODEL_FILENAME)
    translator = get_translator(FROM_LANG, TO_LANG)

    # 2) Glossário (opcional)
    glossary_terms = load_glossary_terms(GLOSSARY_FILE)
    if glossary_terms:
        print(f"Glossário ativo: {len(glossary_terms)} termo(s) serão preservados.")

    # 3) Arquivo de origem
    if not os.path.isfile(SOURCE_FILE):
        raise FileNotFoundError(f"Arquivo de origem '{SOURCE_FILE}' não encontrado em {os.getcwd()}")

    with open(SOURCE_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()

    # 4) Tradução
    print("Iniciando tradução (100% local)...")
    t0 = time.time()
    translated_lines = process_markdown(lines, translator, glossary_terms)
    dt = time.time() - t0

    # 5) Saída
    with open(TARGET_FILE, 'w', encoding='utf-8', newline='') as f:
        f.writelines(translated_lines)

    total_chars = sum(len(l) for l in lines)
    print("\nTradução concluída!")
    print(f"Arquivo de saída: {TARGET_FILE}")
    print(f"Tamanho original: {total_chars:,} caracteres")
    print(f"Tempo total: {dt:,.1f} s")
    if dt > 0:
        print(f"Vazão média: {total_chars/dt:,.0f} chars/s")


if __name__ == "__main__":
    main()
