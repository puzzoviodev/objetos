
# Tradução Offline de Markdown (EN → PT-BR) com Argos Translate

Este pacote traduz **`arquivoorigem.md`** (no mesmo diretório) de **inglês** para **português (Brasil)** **100% offline**, usando **Argos Translate**.

> **Importante:** Você precisa do **modelo Argos** `en_pt.argosmodel` localmente, ao lado do script, para operar **sem internet**.

---

## 📂 Conteúdo

- `traduz_md_local.py` — script principal de tradução com preservação de Markdown (código, links, imagens, URLs, YAML) e **glossário opcional**.
- `requirements.txt` — dependência mínima (`argostranslate`).
- `glossario_termos_nao_traduzir.txt` — **opcional**: termos que **não devem** ser traduzidos (um por linha). Arquivo vazio por padrão.

---

## 🚀 Como usar (passo a passo)

1. **Python 3.8+** instalado.
2. **Crie e ative** um ambiente virtual (recomendado):
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # Linux/macOS:
   source .venv/bin/activate
   ```
3. **Instale as dependências**:
   ```bash
   pip install -r requirements.txt
   ```
4. **Coloque ao lado do script**:
   - O arquivo **`arquivoorigem.md`** (texto em inglês);
   - O **modelo** **`en_pt.argosmodel`** (pacote Argos EN→PT).
5. **(Opcional) Glossário**: edite `glossario_termos_nao_traduzir.txt` e liste termos que **não** devem ser traduzidos (ex.: `Django`, `middleware`, `QuerySet`). **Um por linha**.
6. **Execute**:
   ```bash
   python traduz_md_local.py
   ```
7. **Saída**: será gerado `arquivoorigem.pt-BR.md` no mesmo diretório.

---

## 🧠 Como o script preserva Markdown

- **Blocos de código** (```...``` / `~~~`) e **códigos inline** (`` `assim` ``) **não** são traduzidos.
- **Links** `[rótulo](url)`: traduz **apenas o rótulo**, mantém a **URL**.
- **Imagens** `![]()`: preservadas integralmente.
- **URLs soltas** `http(s)://...`: preservadas.
- **Front‑matter YAML**: não é traduzido.
- **Glossário** (opcional): termos listados são **congelados** para não sofrer tradução.

---

## ⏱ Desempenho (estimativas)

- Em hardware comum, 700 páginas podem ser traduzidas em **minutos**. O tempo exato depende do seu CPU/GPU e do tamanho real em palavras/caracteres.
- O script mostra **progresso** (chars/s) no terminal.

---

## ❓ Dúvidas comuns

- **Precisa de internet?** Não. O modelo `.argosmodel` é instalado localmente; após isso, tudo roda offline.
- **Onde consigo o `en_pt.argosmodel`?** Baixe previamente do projeto Argos/LibreTranslate e **coloque o arquivo ao lado do script**. O nome padrão esperado é `en_pt.argosmodel`.
- **Posso manter termos em inglês?** Sim, use o arquivo `glossario_termos_nao_traduzir.txt`.

---

## ⚠️ Observações

- Markdown muito heterogêneo pode precisar de pequenos ajustes pós‑tradução.
- Se o arquivo for enorme, é normal ver o uso de CPU aumentar durante a tradução.

---

## 📝 Licença

Este pacote de exemplo é fornecido "como está", para uso educativo e interno.
