# -*- coding: utf-8 -*-
"""
Script: traduz_md_local_v2.py
Objetivo: Tradução técnica de Markdown (EN -> PT-BR) 100% local com Argos Translate,
          preservando código e termos técnicos via:
            - proteção de blocos de código e inline code
            - proteção de links/URLs/imagens/front‑matter
            - glossário de termos NÃO traduzíveis (personalizável)
            - heurísticas "Modo Técnico" para congelar identificadores, caminhos, comandos, chaves JSON/YAML

Uso simples:
  - Coloque: arquivoorigem.md, en_pt.argosmodel, este script no mesmo diretório.
  - (Opcional) Ajuste GLOSSARIO_PADRAO e arquivo glossário.
  - Execute: python traduz_md_local_v2.py

Saída: arquivoorigem.pt-BR.md

Requisitos:
  - Python 3.8+
  - pip install argostranslate
"""

import os
import re
import time
from typing import Dict, List, Tuple
from argostranslate import package as argos_package
from argostranslate import translate as argos_translate

# ----------------------------- CONFIG ----------------------------- #
SOURCE_FILE = "arquivoorigem.md"          # arquivo de entrada (mesmo diretório)
TARGET_FILE = "arquivoorigem.pt-BR.md"    # arquivo de saída
FROM_LANG = "en"                          # origem
TO_LANG = "pt"                            # destino (pt cobre pt-BR no Argos)
LOCAL_MODEL_FILENAME = "en_pt.argosmodel" # pacote local Argos (obrigatório p/ offline)
GLOSSARY_FILE = "glossario_termos_nao_traduzir.txt"  # opcional

# Ativa heurísticas do "Modo Técnico" para preservar termos comuns em docs de Python/Django
MODO_TECNICO = True

# Se True, preserva o ALT de imagens também (além da URL)
PRESERVAR_ALT_IMAGENS = True

# Glossário padrão (você pode editar/expandir):
GLOSSARIO_PADRAO: List[str] = [
    # Python geral
    "Python", "pip", "venv", "virtualenv", "requirements.txt", "setup.py", "pyproject.toml",
    "PEP", "PEP8", "PEP-8", "pipenv", "poetry", "uv", "conda",
    # Django
    "Django", "ASGI", "WSGI", "manage.py", "settings.py", "wsgi.py", "asgi.py",
    "QuerySet", "Model", "ModelAdmin", "APIView", "Serializer", "ORM", "Migrations",
    "urls.py", "views.py", "models.py", "forms.py", "admin.py",
    "middleware", "template", "context", "staticfiles", "Media", "AppConfig",
    # DRF / FastAPI / etc
    "DRF", "Django REST Framework", "OpenAPI", "Swagger", "Uvicorn", "Gunicorn",
    # Web/devops/comandos
    "Nginx", "Apache", "Docker", "docker-compose.yaml", "docker-compose.yml",
    "systemd", "nginx.conf", "gunicorn.conf.py",
    # Banco de dados / termos comuns
    "PostgreSQL", "MySQL", "SQLite", "Redis", "MongoDB",
    # Conceitos técnicos
    "Middleware", "Query", "Fixture", "Slug", "UUID", "JWT", "JWTAuth", "OAuth2",
    # Outros termos úteis
    "Bootstrap", "jQuery", "Webpack", "Node.js", "npm", "yarn",
]

# --------------------------- REGEX COMPILADAS --------------------------- #
# Fenced code blocks e inline code
RE_FENCE = re.compile(r"^(\s*)(`{3,}|~{3,})(.*)$")
RE_INLINE_CODE = re.compile(r"`[^`]*`")
# Links/Imagens/URLs
RE_IMAGE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
RE_LINK = re.compile(r"(?<!!)\[([^\]]+)\]\(([^)]+)\)")
RE_BARE_URL = re.compile(r"(?<!\()(?P<url>https?://[^\s)]+)")
# YAML front‑matter
RE_YAML_DELIM = re.compile(r"^\s*---\s*$")

# Heurísticas do Modo Técnico
# 1) snake_case (com sublinhado)
RE_SNAKE = re.compile(r"\b[a-z][a-z0-9_]*_[a-z0-9_]+\b")
# 2) PascalCase/CamelCase com 2+ componentes (ModelAdmin, QuerySet, APIView)
RE_CAMEL = re.compile(r"\b(?:[A-Z][a-z0-9]+){2,}[A-Za-z0-9]*\b")
# 3) módulos/submódulos: something.something (django.contrib.auth)
RE_DOTTED = re.compile(r"\b[a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*)+\b")
# 4) caminhos de arquivos Unix/Windows (heurística simples)
RE_PATH = re.compile(r"(?:\b[A-Za-z]:\\[^\s]+|/[^\s]+(?:/[\w.\-]+)*)")
# 5) comandos de terminal em linha (ex.: pip install x, python manage.py migrate)
RE_CMD = re.compile(r"\b(?:pip|python3?|py|uv|poetry|pipenv)\s+[\w.\-/]+(?:\s+[\w.\-/]+)*\b")
# 6) chaves JSON/YAML ("key": ou key:)
RE_JSON_KEY = re.compile(r"\"([^\"]+)\"\s*:\s*")
RE_YAML_KEY = re.compile(r"^\s*([A-Za-z_][\w\-]*)\s*:\s*", re.MULTILINE)

# --------------------------- FUNÇÕES BASE --------------------------- #

def ensure_local_model_installed(from_code: str, to_code: str, local_model_filename: str) -> None:
    installed_langs = argos_translate.get_installed_languages()
    for lang_from in installed_langs:
        if lang_from.code == from_code:
            for possible_to in lang_from.translations:
                if possible_to.to_language.code == to_code:
                    return  # já instalado
    path = os.path.join(os.getcwd(), local_model_filename)
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"Modelo Argos '{local_model_filename}' não encontrado. Coloque-o ao lado do script." )
    argos_package.install_from_path(path)


def get_translator(from_code: str, to_code: str):
    langs = argos_translate.get_installed_languages()
    src = next((l for l in langs if l.code == from_code), None)
    dst = next((l for l in langs if l.code == to_code), None)
    if not src or not dst:
        raise RuntimeError("Idiomas não encontrados após instalação do modelo.")
    return src.get_translation(dst)


def load_glossary(arquivo: str) -> List[str]:
    terms: List[str] = []
    if os.path.isfile(arquivo):
        with open(arquivo, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                t = line.strip()
                if t and not t.startswith('#'):
                    terms.append(t)
    # adiciona glossário padrão e remove duplicatas preservando ordem
    seen = set()
    all_terms: List[str] = []
    for t in (terms + GLOSSARIO_PADRAO):
        if t not in seen:
            seen.add(t)
            all_terms.append(t)
    # ordenar por tamanho decrescente ajuda a evitar sobreposição
    all_terms.sort(key=len, reverse=True)
    return all_terms

# --------------------------- PLACEHOLDERS --------------------------- #

def protect_with_regex(text: str, pattern: re.Pattern, bucket: Dict[str, str], tag: str) -> str:
    def _repl(m):
        key = f"__{tag}_{len(bucket)}__"
        bucket[key] = m.group(0)
        return key
    return pattern.sub(_repl, text)


def protect_inline_code(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        key = f"__CODE_{len(bucket)}__"
        bucket[key] = m.group(0)
        return key
    return RE_INLINE_CODE.sub(_repl, text)


def protect_images(text: str, bucket: Dict[str, str]) -> str:
    # Se PRESERVAR_ALT_IMAGENS=True, preserva a imagem inteira; senão, preserva só URL
    if PRESERVAR_ALT_IMAGENS:
        def _repl(m):
            key = f"__IMG_{len(bucket)}__"
            bucket[key] = m.group(0)
            return key
        return RE_IMAGE.sub(_repl, text)
    else:
        # protege apenas a URL (rótulo pode ser traduzido)
        def _repl(m):
            alt, url = m.group(1), m.group(2)
            key = f"__IMGURL_{len(bucket)}__"
            bucket[key] = url
            return f"![{alt}]({key})"
        return RE_IMAGE.sub(_repl, text)


def extract_links(text: str, labels: List[str], urls: List[str]) -> str:
    def _repl(m):
        label = m.group(1)
        url = m.group(2)
        idx = len(labels)
        labels.append(label)
        urls.append(url)
        return f"__XREF_{idx}__"
    return RE_LINK.sub(_repl, text)


def protect_bare_urls(text: str, bucket: Dict[str, str]) -> str:
    def _repl(m):
        url = m.group("url")
        key = f"__URL_{len(bucket)}__"
        bucket[key] = url
        return key
    return RE_BARE_URL.sub(_repl, text)


def protect_terms(text: str, terms: List[str], bucket: Dict[str, str]) -> str:
    for term in terms:
        key = f"__TERM_{len(bucket)}__"
        bucket[key] = term
        # usa \b se for palavra simples (letras/dígitos/_/-); senão, literal
        if re.match(r"^[\w\-\.]+$", term):
            pattern = re.compile(rf"\b{re.escape(term)}\b")
        else:
            pattern = re.compile(re.escape(term))
        text = pattern.sub(key, text)
    return text


def restore_placeholders(text: str, bucket: Dict[str, str]) -> str:
    for key in sorted(bucket.keys(), key=len, reverse=True):
        text = text.replace(key, bucket[key])
    return text

# --------------------- SEGMENTAÇÃO EM PARÁGRAFOS --------------------- #

def split_into_paragraphs(lines: List[str]) -> List[List[str]]:
    paragraphs: List[List[str]] = []
    current: List[str] = []
    in_fence = False
    in_yaml = False
    yaml_started = False

    for line in lines:
        # YAML front‑matter
        if not yaml_started and RE_YAML_DELIM.match(line):
            yaml_started = True
            in_yaml = True
            if current:
                paragraphs.append(current)
                current = []
            paragraphs.append([line])
            continue
        elif yaml_started and in_yaml and RE_YAML_DELIM.match(line):
            paragraphs.append([line])
            in_yaml = False
            continue
        elif in_yaml:
            paragraphs.append([line])
            continue

        # Fences
        m = RE_FENCE.match(line)
        if m:
            if not in_fence:
                if current:
                    paragraphs.append(current)
                    current = []
                in_fence = True
                paragraphs.append([line])
            else:
                paragraphs.append([line])
                in_fence = False
            continue

        if in_fence:
            paragraphs.append([line])
            continue

        # Texto normal / quebras
        if line.strip() == "":
            if current:
                paragraphs.append(current)
                current = []
            paragraphs.append([line])
        else:
            current.append(line)

    if current:
        paragraphs.append(current)

    return paragraphs

# -------------------------- TRADUÇÃO DE BLOCO -------------------------- #

def translate_paragraph(paragraph: str, translator, glossary_terms: List[str]) -> str:
    bucket: Dict[str, str] = {}
    labels: List[str] = []
    urls: List[str] = []

    # 1) Proteções básicas
    stage = protect_images(paragraph, bucket)
    stage = protect_inline_code(stage, bucket)
    stage = protect_bare_urls(stage, bucket)
    stage = extract_links(stage, labels, urls)

    # 2) Modo Técnico (heurísticas)
    if MODO_TECNICO:
        stage = protect_with_regex(stage, RE_SNAKE, bucket, tag="SNAKE")
        stage = protect_with_regex(stage, RE_CAMEL, bucket, tag="CAMEL")
        stage = protect_with_regex(stage, RE_DOTTED, bucket, tag="MOD")
        stage = protect_with_regex(stage, RE_PATH, bucket, tag="PATH")
        stage = protect_with_regex(stage, RE_CMD, bucket, tag="CMD")
        # chaves JSON/YAML: preserva o trecho da chave e os dois pontos
        def _repl_json(m):
            key = f"__JKEY_{len(bucket)}__"
            bucket[key] = m.group(0)  # inclui aspas e dois pontos
            return key
        stage = RE_JSON_KEY.sub(_repl_json, stage)
        def _repl_yaml(m):
            key = f"__YKEY_{len(bucket)}__"
            bucket[key] = m.group(0)  # inclui a chave e dois pontos
            return key
        stage = RE_YAML_KEY.sub(_repl_yaml, stage)

    # 3) Glossário (após heurísticas, para não sobrepor placeholders já criados)
    stage = protect_terms(stage, glossary_terms, bucket)

    # 4) Traduzir labels de links
    translated_labels = [translator.translate(lbl) for lbl in labels]

    # 5) Traduzir parágrafo restante
    translated = translator.translate(stage)

    # 6) Reconstituir links
    for i, (lab_pt, url_orig) in enumerate(zip(translated_labels, urls)):
        translated = translated.replace(f"__XREF_{i}__", f"[{lab_pt}]({url_orig})")

    # 7) Restaurar placeholders
    translated = restore_placeholders(translated, bucket)
    return translated

# ---------------------------- PIPELINE GERAL ---------------------------- #

def process_markdown(lines: List[str], translator, glossary_terms: List[str]) -> List[str]:
    out_lines: List[str] = []
    paragraphs = split_into_paragraphs(lines)

    in_yaml = False
    yaml_started = False

    total_chars = sum(len("".join(p)) for p in paragraphs)
    translated_chars = 0
    t0 = time.time()

    for block in paragraphs:
        if len(block) == 1 and RE_YAML_DELIM.match(block[0]):
            out_lines.append(block[0])
            if not yaml_started:
                yaml_started = True
                in_yaml = True
            else:
                in_yaml = False
            continue

        if in_yaml:
            out_lines.extend(block)
            continue

        if len(block) == 1 and (RE_FENCE.match(block[0]) or block[0].strip() == ""):
            out_lines.append(block[0])
            continue

        paragraph_text = "".join(block)
        translated_chars += len(paragraph_text)
        out_lines.append(translate_paragraph(paragraph_text, translator, glossary_terms))

        elapsed = time.time() - t0
        speed = (translated_chars / elapsed) if elapsed > 0 else 0
        pct = (translated_chars / total_chars) * 100 if total_chars > 0 else 100
        print(f"[Modo Técnico] {pct:6.2f}% | {translated_chars}/{total_chars} chars | {speed:,.0f} chars/s | {elapsed:,.1f}s", end='\r')

    print()
    return out_lines

# ------------------------------- MAIN ------------------------------- #

def main():
    ensure_local_model_installed(FROM_LANG, TO_LANG, LOCAL_MODEL_FILENAME)
    translator = get_translator(FROM_LANG, TO_LANG)

    glossary_terms = load_glossary(GLOSSARY_FILE)
    print(f"Glossário ativo: {len(glossary_terms)} termo(s) (arquivo + padrão). Modo Técnico: {MODO_TECNICO}")

    if not os.path.isfile(SOURCE_FILE):
        raise FileNotFoundError(f"Arquivo '{SOURCE_FILE}' não encontrado em {os.getcwd()}")

    with open(SOURCE_FILE, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()

    print("Iniciando tradução (100% local) com proteções técnicas...")
    t0 = time.time()
    out_lines = process_markdown(lines, translator, glossary_terms)
    dt = time.time() - t0

    with open(TARGET_FILE, 'w', encoding='utf-8', newline='') as f:
        f.writelines(out_lines)

    total = sum(len(l) for l in lines)
    print("\nConcluído!")
    print(f"Arquivo gerado: {TARGET_FILE}")
    print(f"Tamanho original: {total:,} caracteres | Tempo: {dt:,.1f}s | Vazão: {total/dt:,.0f} chars/s" if dt>0 else "")

if __name__ == '__main__':
    main()
