
# Tradução Offline de Markdown (EN → PT‑BR) — **V2 (Modo Técnico)**

Esta versão aprimora a proteção de **termos técnicos** e **código** durante a tradução com **Argos Translate** (100% offline).

## Novidades da V2
- **Modo Técnico**: congela automaticamente
  - `snake_case`, `dotted.modules`, **caminhos** (`/var/www/...`, `C:\...`),
  - **comandos** de terminal (`pip install`, `python manage.py migrate`),
  - **chaves JSON/YAML** (ex.: `"DEBUG":`, `ALLOWED_HOSTS:`),
  - **Camel/PascalCase** com múltiplos componentes (ex.: `ModelAdmin`, `APIView`).
- **Glossário padrão** com termos frequentes (Django, DRF, etc.) + **glossário do usuário** (`glossario_termos_nao_traduzir.txt`).
- Preservação de **imagens** com ALT (opcional, ativado por padrão).

## Como usar
1. **Python 3.8+** e dependências:
   ```bash
   pip install -r requirements.txt
   ```
2. Coloque ao lado do script:
   - `arquivoorigem.md` (inglês)
   - `en_pt.argosmodel` (modelo Argos EN→PT — necessário para offline)
3. (Opcional) Edite `glossario_termos_nao_traduzir.txt` e acrescente termos internos.
4. Execute:
   ```bash
   python traduz_md_local_v2.py
   ```
5. Saída: `arquivoorigem.pt-BR.md`.

## Notas
- Blocos de código e inline code **nunca** são traduzidos.
- Links: traduz apenas o **rótulo**; **URL** mantida.
- Se houver termos que **devem** ser traduzidos (ex.: “Model” → “Modelo”), **não os inclua** no glossário.

## Teste rápido
Use `exemplos_teste.md` para validar a proteção. Gere a tradução e compare os trechos protegidos.
